import gymnasium as gym
import highway_env
import torch as th
from stable_baselines3 import PPO

# 设置模型路径
MODEL_PATH = "C:\\Users\\21753\\Desktop\\RL3\\models\\ppo_intersection_v0.zip"

# 创建交叉路口环境
env = gym.make("intersection-v0", render_mode="rgb_array")

# 加载训练好的模型
model = PPO.load(MODEL_PATH)

num_episodes = 30  # 设定游戏次数
for episode in range(num_episodes):
    print(f" 开始第 {episode + 1} 局游戏...")
    obs, info = env.reset()
    done = False
    episode_reward = 0  # 记录当前局的总奖励

    print("初始 obs.shape:", obs.shape)
    print("动作空间:", env.action_space)

    while not done:
        action, _states = model.predict(obs, deterministic=False)  #  允许一定随机性
        print(f" 选择的动作: {action}")

        obs, reward, done, truncated, info = env.step(action)
        episode_reward += reward  # 累计奖励
        print(f"奖励: {reward}")
        print(obs)

        env.render()

    print(f" 第 {episode + 1} 局游戏完成，总奖励: {episode_reward:.2f}\n")

env.close()  # 关闭环境
print("🎉 游戏运行完毕！")
