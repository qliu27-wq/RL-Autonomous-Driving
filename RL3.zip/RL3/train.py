import os
import gymnasium as gym
import highway_env
import torch as th
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
import multiprocessing as mp

import numpy as np

class PadObservation(gym.ObservationWrapper):
    def __init__(self, env, target_shape=(15, 7)):  # 目标形状
        super().__init__(env)
        self.target_shape = target_shape
        low = np.full(target_shape, env.observation_space.low.min(), dtype=np.float32)
        high = np.full(target_shape, env.observation_space.high.max(), dtype=np.float32)
        self.observation_space = gym.spaces.Box(low, high, dtype=np.float32)

    def observation(self, obs):
        padded_obs = np.zeros(self.target_shape, dtype=np.float32)
        padded_obs[:obs.shape[0], :] = obs  # 只填充有效部分
        return padded_obs


# 设定存储路径
BASE_DIR = "C:\\Users\\21753\\Desktop\\RL3"
MODEL_DIR = os.path.join(BASE_DIR, "models")
os.makedirs(MODEL_DIR, exist_ok=True)  # 确保 `models` 目录存在

# 创建 Intersection 环境（优化环境参数）
def make_env():
    env = gym.make("intersection-v0", render_mode=None)
    env.unwrapped.configure({
        "observation": {
            "type": "Kinematics",
            "vehicles_count": 10,  # 让智能体训练更快
            "features": ["presence", "x", "y", "vx", "vy", "cos_h", "sin_h"],
            "absolute": True,
            "flatten": False,
            "observe_intentions": False
        },
        "action": {
            "type": "DiscreteMetaAction",
            "longitudinal": False,
            "lateral": True
        },
        "duration": 13,
        "destination": "o1",
        "initial_vehicle_count": 8,
        "spawn_probability": 0.7,
        "collision_reward": -5.0,
        "normalize_reward": False
    })
    env = PadObservation(env, target_shape=(15, 7))  # 适配 observation 形状
    return env


# 运行训练代码
if __name__ == "__main__":
    mp.freeze_support()  # Windows 多进程支持

    
    env = make_vec_env(make_env, n_envs=1)  

    #  训练参数优化
    model = PPO(
        "MlpPolicy",
        env,
        verbose=1 # 2048 打印一次日志(默认)
        # n_steps=2048,  # 2048 打印一次日志(默认)
        # batch_size=512,  # 增大 batch_size，提高训练稳定性
        # gamma=0.995,  # 提高长期决策能力
        # gae_lambda=0.98,  #  增强优势估计，提高学习效率
        # clip_range=0.2,  # 默认剪切范围
        # learning_rate=3e-4,  # 适中的学习率，防止发散
        # ent_coef=0.01,  # 适当增加探索能力
        # verbose=1,  # 打印日志
        # tensorboard_log=os.path.join(BASE_DIR, "tensorboard_logs"),
        # device="cuda"  # GPU 加速训练
    )

    # 训练 2050步
    total_timesteps = 2050  # 真正的训练步数 最好是2048的倍数否则训练时一定会多一个轮次
    print(f"训练开始，总共 {total_timesteps} 步...")
    model.learn(total_timesteps=2050, progress_bar=True) ##进度条数字和上面的要一样
    # 保存模型
    model_path = os.path.join(MODEL_DIR, "ppo_intersection_v0")
    model.save(model_path)
    print(f"训练完成，模型已保存到: {model_path}.zip")
